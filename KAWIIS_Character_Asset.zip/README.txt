KAWIIS CHASE WITH MEGAN - character asset

Upload the file assets/Male_Casual.fbx to your GitHub repository at:
assets/Male_Casual.fbx

Keep the filename and capital letters exactly as shown.
This is the extracted FBX from your uploaded Animated Men Pack ZIP.
